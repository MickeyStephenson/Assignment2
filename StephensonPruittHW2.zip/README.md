# Assignment2
CS371 Mobile Computing Assignment 2
Keen Bayonet Viewer
Mickey Stephenson
Adam Pruitt
Solar2D
Lua

Mickey : image sheet, animations
Adam : Sliders, animations, switch